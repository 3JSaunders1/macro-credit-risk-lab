"""
api/server.py
-------------
FastAPI REST API exposing the macro-credit pipeline.

Endpoints
---------
GET  /health                        Health check
GET  /forecast_and_score            Full pipeline with default data
POST /score                         Score a single custom macro scenario
GET  /stress_test                   Run all standard stress scenarios

Start with:
    uvicorn api.server:app --reload --port 8000

Docs available at:
    http://localhost:8000/docs      (Swagger UI)
    http://localhost:8000/redoc     (ReDoc)
"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import pandas as pd

from pipeline.run_pipeline import run_pipeline
from models.credit_model import CreditModel, StressScenario

app = FastAPI(
    title="Macro-Driven Credit Scoring API",
    description=(
        "A VAR-based macro forecasting model chained with a logistic "
        "Probability of Default (PD) model. Suitable for stress testing "
        "and scenario analysis workflows."
    ),
    version="1.0.0",
)


# ------------------------------------------------------------------
# Pydantic schemas
# ------------------------------------------------------------------

class MacroInputs(BaseModel):
    unemployment: float = Field(..., ge=0, le=30, description="Unemployment rate (%)")
    inflation: float = Field(..., ge=-5, le=30, description="Inflation rate (%)")


class PDResponse(BaseModel):
    unemployment: float
    inflation: float
    predicted_pd: float
    rating: str


class ForecastResponse(BaseModel):
    forecast: dict
    forecast_ci: dict
    predicted_pd: float
    rating: str
    sensitivity: dict
    var_lags_used: int


class StressTestResponse(BaseModel):
    scenarios: list[dict]


# ------------------------------------------------------------------
# Routes
# ------------------------------------------------------------------

@app.get("/health", tags=["Meta"])
def health():
    """Simple liveness check."""
    return {"status": "ok", "service": "credit-scoring-api"}


@app.get("/forecast_and_score", response_model=ForecastResponse, tags=["Pipeline"])
def forecast_and_score():
    """
    Run the full pipeline: load data → fit VAR → forecast → score.
    Returns 1-step-ahead macro forecast + PD estimate.
    """
    try:
        result = run_pipeline(run_stress=False, verbose=False)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    return {
        "forecast": result["forecast"],
        "forecast_ci": result["forecast_ci"],
        "predicted_pd": round(result["predicted_pd"], 6),
        "rating": result["rating"],
        "sensitivity": result["sensitivity"],
        "var_lags_used": result["var_lags_used"],
    }


@app.post("/score", response_model=PDResponse, tags=["Credit Model"])
def score_scenario(inputs: MacroInputs):
    """
    Score a single custom macro scenario without running the VAR.
    Useful for rapid what-if analysis.

    Example body:
        {"unemployment": 8.5, "inflation": 4.0}
    """
    model = CreditModel()
    pd_val = model.predict_pd(inputs.unemployment, inputs.inflation)
    rating = model.pd_to_rating(pd_val)

    return PDResponse(
        unemployment=inputs.unemployment,
        inflation=inputs.inflation,
        predicted_pd=round(pd_val, 6),
        rating=rating,
    )


@app.get("/stress_test", response_model=StressTestResponse, tags=["Credit Model"])
def stress_test():
    """
    Run standard stress scenarios (Baseline, Adverse, Severely Adverse, etc.)
    and return PD and rating for each.
    """
    model = CreditModel()
    df = model.stress_test()
    return {"scenarios": df.to_dict(orient="records")}


@app.post("/stress_test/custom", response_model=StressTestResponse, tags=["Credit Model"])
def custom_stress_test(scenarios: list[MacroInputs]):
    """
    Run PD model over user-defined macro scenarios.

    Example body:
        [
            {"unemployment": 5.0, "inflation": 2.0},
            {"unemployment": 10.0, "inflation": 5.0}
        ]
    """
    model = CreditModel()
    custom = [
        StressScenario(
            name=f"Custom {i+1}",
            unemployment=s.unemployment,
            inflation=s.inflation,
        )
        for i, s in enumerate(scenarios)
    ]
    df = model.stress_test(custom)
    return {"scenarios": df.to_dict(orient="records")}
