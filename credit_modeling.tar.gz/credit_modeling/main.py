"""
main.py
-------
CLI entry point for the macro-credit pipeline.

Usage:
    python main.py                  # run with defaults
    python main.py --lags 2         # specify VAR lag order
    python main.py --no-stress      # skip stress scenarios
    python main.py --quiet          # suppress intermediate output
"""
import argparse
from pipeline.run_pipeline import run_pipeline


def parse_args():
    p = argparse.ArgumentParser(description="Macro-Driven Credit Scoring Pipeline")
    p.add_argument("--lags", type=int, default=None,
                   help="VAR lag order (default: AIC selection)")
    p.add_argument("--no-stress", action="store_true",
                   help="Skip stress test scenarios")
    p.add_argument("--quiet", action="store_true",
                   help="Suppress pipeline verbose output")
    p.add_argument("--data", type=str, default="data/macro_data.csv",
                   help="Path to macro data CSV")
    return p.parse_args()


def print_section(title: str):
    width = 50
    print("\n" + "=" * width)
    print(f"  {title}")
    print("=" * width)


def main():
    args = parse_args()

    result = run_pipeline(
        data_path=args.data,
        var_lags=args.lags,
        run_stress=not args.no_stress,
        verbose=not args.quiet,
    )

    # --- Summary output ---
    print_section("Macro Forecast (1-Step Ahead)")
    fc = result["forecast"]
    ci = result["forecast_ci"]
    print(f"  Unemployment : {fc['unemployment']:.2f}%")
    print(f"    90% CI     : [{ci['unemployment']['lower']:.2f}%, "
          f"{ci['unemployment']['upper']:.2f}%]")
    print(f"  Inflation    : {fc['inflation']:.2f}%")
    print(f"    90% CI     : [{ci['inflation']['lower']:.2f}%, "
          f"{ci['inflation']['upper']:.2f}%]")

    print_section("Credit Risk Estimate")
    print(f"  Probability of Default : {result['predicted_pd']:.4%}")
    print(f"  Internal Rating        : {result['rating']}")

    sens = result["sensitivity"]
    print_section("Sensitivity (per 1pp shock)")
    print(f"  +1pp Unemployment → ΔPD: {sens['unemployment_shock_delta']:+.4%}")
    print(f"  +1pp Inflation    → ΔPD: {sens['inflation_shock_delta']:+.4%}")

    if result.get("stress_test") is not None:
        print_section("Stress Test Scenarios")
        print(result["stress_test"].to_string(index=False))

    print()


if __name__ == "__main__":
    main()
