"""
models/credit_model.py
----------------------
Macro-driven Probability of Default (PD) model.

Architecture
------------
The model is a logistic regression where the linear predictor (log-odds)
is a function of macro variables:

    log(PD / (1 - PD)) = β₀ + β₁·unemployment + β₂·inflation

The coefficients can be:
  - Set manually (current default, useful for illustrative/stress scenarios)
  - Estimated from historical default data via `fit()` (uses sklearn)

Stress Testing
--------------
`stress_test()` runs the model across a grid of macro scenarios and
returns a DataFrame of PD estimates — useful for regulatory DFAST/CCAR
scenario analysis, which is exactly what you'll do at the new role.

Rating Buckets
--------------
`pd_to_rating()` maps PD to a simplified internal rating scale, which
is standard practice in credit risk (Basel II/III framework).
"""
import numpy as np
import pandas as pd
from dataclasses import dataclass


@dataclass
class StressScenario:
    name: str
    unemployment: float
    inflation: float


# Standard macro stress scenarios (loosely inspired by Fed DFAST scenarios)
STANDARD_SCENARIOS = [
    StressScenario("Baseline", 4.0, 2.5),
    StressScenario("Adverse", 7.0, 4.0),
    StressScenario("Severely Adverse", 12.0, 1.5),
    StressScenario("Stagflation", 8.0, 9.0),
    StressScenario("COVID-like Shock", 15.0, 0.5),
]


class CreditModel:
    """
    Logistic PD model with optional sklearn fitting.

    Parameters
    ----------
    beta_0 : float  Intercept (log-odds at zero macro inputs)
    beta_1 : float  Unemployment coefficient (positive → higher PD)
    beta_2 : float  Inflation coefficient (positive → higher PD when inflation rises)
    """

    # Simplified internal rating scale: PD thresholds → rating label
    RATING_SCALE = [
        (0.002, "AAA"),
        (0.005, "AA"),
        (0.010, "A"),
        (0.020, "BBB"),
        (0.050, "BB"),
        (0.100, "B"),
        (0.200, "CCC"),
        (1.000, "D"),
    ]

    def __init__(
        self,
        beta_0: float = -3.0,
        beta_1: float = 0.5,   # unemployment: higher → higher PD
        beta_2: float = 0.3,   # inflation: moderate positive relationship
    ):
        self.beta_0 = beta_0
        self.beta_1 = beta_1
        self.beta_2 = beta_2
        self._sklearn_model = None  # populated if fit() is called

    # ------------------------------------------------------------------
    # Core math
    # ------------------------------------------------------------------

    @staticmethod
    def sigmoid(x: float | np.ndarray) -> float | np.ndarray:
        """Numerically stable sigmoid."""
        return np.where(x >= 0,
                        1 / (1 + np.exp(-x)),
                        np.exp(x) / (1 + np.exp(x)))

    def _log_odds(self, unemployment: float, inflation: float) -> float:
        return (
            self.beta_0
            + self.beta_1 * unemployment
            + self.beta_2 * inflation
        )

    # ------------------------------------------------------------------
    # Prediction
    # ------------------------------------------------------------------

    def predict_pd(self, unemployment: float, inflation: float) -> float:
        """Point estimate of PD given macro inputs."""
        z = self._log_odds(unemployment, inflation)
        return float(self.sigmoid(z))

    def predict_pd_batch(self, df: pd.DataFrame) -> pd.Series:
        """
        Vectorized PD prediction over a DataFrame.

        Parameters
        ----------
        df : pd.DataFrame with columns ['unemployment', 'inflation']

        Returns
        -------
        pd.Series of PD values
        """
        z = (
            self.beta_0
            + self.beta_1 * df["unemployment"]
            + self.beta_2 * df["inflation"]
        )
        return self.sigmoid(z.values).astype(float)

    # ------------------------------------------------------------------
    # Sklearn fitting (if you have labeled default data)
    # ------------------------------------------------------------------

    def fit(self, X: pd.DataFrame, y: pd.Series) -> "CreditModel":
        """
        Fit the model using observed default data.

        Parameters
        ----------
        X : pd.DataFrame  columns: [unemployment, inflation]
        y : pd.Series     binary default indicator (1=default, 0=no default)

        Updates beta_0, beta_1, beta_2 from fitted sklearn LogisticRegression.
        """
        try:
            from sklearn.linear_model import LogisticRegression
            from sklearn.preprocessing import StandardScaler
        except ImportError:
            raise ImportError("scikit-learn required for fitting. pip install scikit-learn")

        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X[["unemployment", "inflation"]])

        lr = LogisticRegression(max_iter=500)
        lr.fit(X_scaled, y)

        self._sklearn_model = (lr, scaler)
        # Back out unscaled coefficients for interpretability
        self.beta_1 = float(lr.coef_[0][0] / scaler.scale_[0])
        self.beta_2 = float(lr.coef_[0][1] / scaler.scale_[1])
        self.beta_0 = float(lr.intercept_[0]
                            - self.beta_1 * scaler.mean_[0]
                            - self.beta_2 * scaler.mean_[1])

        print(f"[CreditModel] Fitted: β₀={self.beta_0:.4f}, "
              f"β_u={self.beta_1:.4f}, β_π={self.beta_2:.4f}")
        return self

    # ------------------------------------------------------------------
    # Rating translation
    # ------------------------------------------------------------------

    def pd_to_rating(self, pd_value: float) -> str:
        """Map a PD to an internal credit rating bucket."""
        for threshold, rating in self.RATING_SCALE:
            if pd_value <= threshold:
                return rating
        return "D"

    # ------------------------------------------------------------------
    # Stress testing
    # ------------------------------------------------------------------

    def stress_test(
        self, scenarios: list[StressScenario] | None = None
    ) -> pd.DataFrame:
        """
        Run PD model across a list of macro scenarios.

        Returns a DataFrame with scenario name, macro inputs, PD, and rating.
        """
        if scenarios is None:
            scenarios = STANDARD_SCENARIOS

        rows = []
        for s in scenarios:
            pd_val = self.predict_pd(s.unemployment, s.inflation)
            rows.append({
                "scenario": s.name,
                "unemployment": s.unemployment,
                "inflation": s.inflation,
                "predicted_pd": round(pd_val, 6),
                "rating": self.pd_to_rating(pd_val),
            })

        return pd.DataFrame(rows)

    # ------------------------------------------------------------------
    # Sensitivity
    # ------------------------------------------------------------------

    def sensitivity(
        self,
        base_unemployment: float = 4.0,
        base_inflation: float = 2.5,
        shock_size: float = 1.0,
    ) -> dict:
        """
        Compute marginal impact of a 1pp shock to each macro variable.
        Useful for explaining model behavior to stakeholders.
        """
        base_pd = self.predict_pd(base_unemployment, base_inflation)
        pd_u_shock = self.predict_pd(base_unemployment + shock_size, base_inflation)
        pd_pi_shock = self.predict_pd(base_unemployment, base_inflation + shock_size)

        return {
            "base_pd": round(base_pd, 6),
            "unemployment_shock_delta": round(pd_u_shock - base_pd, 6),
            "inflation_shock_delta": round(pd_pi_shock - base_pd, 6),
        }

    def __repr__(self):
        return (f"CreditModel(β₀={self.beta_0}, β_u={self.beta_1}, "
                f"β_π={self.beta_2})")
