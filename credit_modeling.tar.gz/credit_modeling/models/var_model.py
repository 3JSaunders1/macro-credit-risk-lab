"""
models/var_model.py
-------------------
Vector Autoregression (VAR) model for macro variable forecasting.

The VAR models the joint dynamics of unemployment and inflation as a
system — each variable is regressed on its own lags and the lags of
all other variables in the system. This captures macro feedback loops
(e.g., rising unemployment leading to lower inflation).

Used to produce 1-step-ahead forecasts that feed into the credit model.
"""
import pandas as pd
import numpy as np
from statsmodels.tsa.api import VAR
from statsmodels.tsa.stattools import adfuller


class VARModel:
    """
    Wraps statsmodels VAR with lag selection, ADF stationarity checks,
    and multi-step forecasting.

    Parameters
    ----------
    lags : int or None
        Number of lags. If None, selected automatically via AIC.
    max_lags : int
        Upper bound for automatic lag selection.
    """

    def __init__(self, lags: int | None = None, max_lags: int = 8):
        self.lags = lags
        self.max_lags = max_lags
        self.model = None
        self.fitted_model = None
        self.columns = None

    # ------------------------------------------------------------------
    # Diagnostics
    # ------------------------------------------------------------------

    def check_stationarity(self, data: pd.DataFrame, sig: float = 0.05) -> dict:
        """
        Run Augmented Dickey-Fuller test on each column.
        Returns a dict with p-values and pass/fail flags.

        VAR requires (weakly) stationary series. If a series fails,
        consider first-differencing before fitting.
        """
        results = {}
        for col in data.columns:
            adf_stat, p_val, *_ = adfuller(data[col].dropna())
            results[col] = {
                "adf_stat": round(adf_stat, 4),
                "p_value": round(p_val, 4),
                "stationary": p_val < sig,
            }
        return results

    # ------------------------------------------------------------------
    # Fit
    # ------------------------------------------------------------------

    def fit(self, data: pd.DataFrame) -> "VARModel":
        """
        Fit the VAR model.

        Parameters
        ----------
        data : pd.DataFrame
            Must contain columns [unemployment, inflation], ordered by time.
        """
        if data.isnull().any().any():
            raise ValueError("Data contains NaN values — clean before fitting.")

        self.columns = list(data.columns)
        self.model = VAR(data)

        if self.lags is None:
            lag_order = self.model.select_order(maxlags=self.max_lags)
            self.lags = lag_order.aic  # use AIC-optimal lag count
            print(f"[VARModel] AIC-optimal lag order: {self.lags}")

        self.fitted_model = self.model.fit(self.lags)
        return self

    # ------------------------------------------------------------------
    # Forecast
    # ------------------------------------------------------------------

    def forecast(self, steps: int = 1) -> np.ndarray:
        """
        Produce `steps`-ahead forecast.

        Returns
        -------
        np.ndarray, shape (steps, n_variables)
            Each row is one forecast horizon. Columns match input data order.
        """
        if self.fitted_model is None:
            raise ValueError("Model must be fit before forecasting.")

        y_input = self.fitted_model.endog[-self.lags :]  # last `p` observations
        forecast = self.fitted_model.forecast(y_input, steps=steps)
        return forecast  # shape: (steps, n_vars)

    def forecast_with_intervals(self, steps: int = 1, alpha: float = 0.1):
        """
        Forecast with confidence intervals (default 90% CI).

        Returns
        -------
        tuple: (point_forecast, lower_bound, upper_bound)
            Each is np.ndarray shape (steps, n_vars).
        """
        if self.fitted_model is None:
            raise ValueError("Model must be fit before forecasting.")

        y_input = self.fitted_model.endog[-self.lags :]
        fc, lower, upper = self.fitted_model.forecast_interval(
            y_input, steps=steps, alpha=alpha
        )
        return fc, lower, upper

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    def summary(self) -> str:
        if self.fitted_model is None:
            return "Model not yet fit."
        return str(self.fitted_model.summary())
