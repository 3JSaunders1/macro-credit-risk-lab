"""
pipeline/run_pipeline.py
------------------------
Orchestrates the full macro → credit scoring pipeline:

  1. Load & validate macro data
  2. Check stationarity (ADF tests)
  3. Fit VAR model, produce 1-step-ahead forecast
  4. Pass forecast into credit model for PD prediction
  5. Run stress scenarios
  6. Return structured results

This is the single entry point — called by main.py and the API server.
"""
import pandas as pd
import numpy as np
from models.var_model import VARModel
from models.credit_model import CreditModel, STANDARD_SCENARIOS


# ------------------------------------------------------------------
# Data loading
# ------------------------------------------------------------------

def load_data(path: str = "data/macro_data.csv") -> pd.DataFrame:
    """
    Load and validate macro data.

    Expected columns: date, unemployment, inflation
    Returns DataFrame with just the numeric columns, sorted by date.
    """
    df = pd.read_csv(path, parse_dates=["date"])
    df = df.sort_values("date").reset_index(drop=True)

    required = {"unemployment", "inflation"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Data missing required columns: {missing}")

    if df[["unemployment", "inflation"]].isnull().any().any():
        raise ValueError("Data contains null values in unemployment or inflation.")

    return df


# ------------------------------------------------------------------
# Main pipeline
# ------------------------------------------------------------------

def run_pipeline(
    data_path: str = "data/macro_data.csv",
    forecast_steps: int = 1,
    var_lags: int | None = None,  # None = auto via AIC
    run_stress: bool = True,
    verbose: bool = True,
) -> dict:
    """
    Execute the macro-credit pipeline end to end.

    Parameters
    ----------
    data_path      : Path to macro CSV
    forecast_steps : How many quarters ahead to forecast
    var_lags       : Number of VAR lags (None = AIC selection)
    run_stress     : Whether to include stress test table in output
    verbose        : Print intermediate results

    Returns
    -------
    dict with keys:
        - forecast          : {unemployment, inflation} point forecasts
        - forecast_ci       : 90% confidence intervals
        - predicted_pd      : float, probability of default
        - rating            : internal rating string
        - sensitivity       : marginal impact of 1pp macro shocks
        - stress_test       : DataFrame of scenario PDs (if run_stress=True)
        - stationarity      : ADF test results for each series
        - var_lags_used     : int, lag order actually used
    """
    # 1. Load data
    df = load_data(data_path)
    macro = df[["unemployment", "inflation"]]

    if verbose:
        print(f"[Pipeline] Loaded {len(macro)} observations "
              f"({df['date'].min().date()} → {df['date'].max().date()})")

    # 2. Stationarity checks
    var_model = VARModel(lags=var_lags)
    stationarity = var_model.check_stationarity(macro)
    if verbose:
        print("\n[Pipeline] Stationarity (ADF p-values):")
        for col, result in stationarity.items():
            flag = "✓" if result["stationary"] else "✗ (non-stationary)"
            print(f"  {col}: p={result['p_value']} {flag}")

    # 3. Fit VAR
    var_model.fit(macro)
    if verbose:
        print(f"\n[Pipeline] VAR fitted with {var_model.lags} lag(s).")

    # 4. Forecast with confidence intervals
    fc_point, fc_lower, fc_upper = var_model.forecast_with_intervals(
        steps=forecast_steps, alpha=0.10
    )

    # Extract 1-step values (first row of forecast array)
    u_hat = float(fc_point[0, 0])
    pi_hat = float(fc_point[0, 1])
    u_lo, u_hi = float(fc_lower[0, 0]), float(fc_upper[0, 0])
    pi_lo, pi_hi = float(fc_lower[0, 1]), float(fc_upper[0, 1])

    if verbose:
        print(f"\n[Pipeline] 1-step Forecast:")
        print(f"  Unemployment: {u_hat:.2f}% (90% CI: {u_lo:.2f}–{u_hi:.2f})")
        print(f"  Inflation:    {pi_hat:.2f}% (90% CI: {pi_lo:.2f}–{pi_hi:.2f})")

    # 5. Credit model
    credit_model = CreditModel()
    pd_hat = credit_model.predict_pd(u_hat, pi_hat)
    rating = credit_model.pd_to_rating(pd_hat)
    sensitivity = credit_model.sensitivity(u_hat, pi_hat)

    if verbose:
        print(f"\n[Pipeline] Credit Scoring:")
        print(f"  Predicted PD: {pd_hat:.4%}")
        print(f"  Rating:       {rating}")
        print(f"  Sensitivity (1pp shock): "
              f"Δ_u={sensitivity['unemployment_shock_delta']:.4%}, "
              f"Δ_π={sensitivity['inflation_shock_delta']:.4%}")

    # 6. Stress test
    stress_df = None
    if run_stress:
        stress_df = credit_model.stress_test(STANDARD_SCENARIOS)
        if verbose:
            print(f"\n[Pipeline] Stress Test Results:\n{stress_df.to_string(index=False)}")

    return {
        "forecast": {"unemployment": u_hat, "inflation": pi_hat},
        "forecast_ci": {
            "unemployment": {"lower": u_lo, "upper": u_hi},
            "inflation": {"lower": pi_lo, "upper": pi_hi},
        },
        "predicted_pd": pd_hat,
        "rating": rating,
        "sensitivity": sensitivity,
        "stress_test": stress_df,
        "stationarity": stationarity,
        "var_lags_used": var_model.lags,
    }
