"""
setup_env.py
------------
Creates a virtual environment and installs all project dependencies.
Run once before starting: python setup_env.py
"""
import os
import subprocess
import sys
import venv
from pathlib import Path

VENV_NAME = "venv"
REQUIREMENTS = "requirements.txt"
MIN_PYTHON = (3, 10)


def check_python_version():
    if sys.version_info < MIN_PYTHON:
        print(f"Error: Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]}+ required.")
        print(f"  Current version: {sys.version}")
        sys.exit(1)
    print(f"Python {sys.version.split()[0]} — OK")


def run_command(command: str):
    try:
        subprocess.check_call(command, shell=True)
    except subprocess.CalledProcessError:
        print(f"\nError running: {command}")
        sys.exit(1)


def create_venv():
    if Path(VENV_NAME).exists():
        print(f"Virtual environment '{VENV_NAME}' already exists — skipping creation.")
    else:
        print(f"Creating virtual environment '{VENV_NAME}'...")
        venv.create(VENV_NAME, with_pip=True)
        print("  Done.")


def get_pip_path() -> str:
    if os.name == "nt":  # Windows
        return str(Path(VENV_NAME) / "Scripts" / "pip.exe")
    return str(Path(VENV_NAME) / "bin" / "pip")


def get_python_path() -> str:
    if os.name == "nt":
        return str(Path(VENV_NAME) / "Scripts" / "python.exe")
    return str(Path(VENV_NAME) / "bin" / "python")


def install_requirements():
    pip = get_pip_path()

    if not Path(REQUIREMENTS).exists():
        print(f"Error: {REQUIREMENTS} not found.")
        sys.exit(1)

    print("Upgrading pip...")
    run_command(f'"{pip}" install --upgrade pip')

    print(f"Installing packages from {REQUIREMENTS}...")
    run_command(f'"{pip}" install -r {REQUIREMENTS}')
    print("  All packages installed.")


def print_activation_instructions():
    print("\n" + "=" * 50)
    print("Setup complete!")
    print("=" * 50)
    if os.name == "nt":
        print(f"  Activate:  {VENV_NAME}\\Scripts\\activate")
    else:
        print(f"  Activate:  source {VENV_NAME}/bin/activate")
    print()
    print("Then run the project:")
    print("  python main.py               # run full pipeline")
    print("  uvicorn api.server:app --reload  # start API server")
    print("  pytest tests/               # run tests")
    print("=" * 50)


def main():
    check_python_version()
    create_venv()
    install_requirements()
    print_activation_instructions()


if __name__ == "__main__":
    main()
