"""
tests/test_suite.py
-------------------
Unit and integration tests for the macro-credit pipeline.

Run: pytest tests/ -v
"""
import numpy as np
import pandas as pd
import pytest
from fastapi.testclient import TestClient


# ------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------

@pytest.fixture
def sample_macro_df():
    """Minimal synthetic macro data for fast tests."""
    np.random.seed(42)
    n = 40
    unemployment = 5.0 + np.cumsum(np.random.normal(0, 0.3, n))
    unemployment = np.clip(unemployment, 2, 20)
    inflation = 2.5 + np.cumsum(np.random.normal(0, 0.2, n))
    inflation = np.clip(inflation, -2, 15)
    return pd.DataFrame({"unemployment": unemployment, "inflation": inflation})


# ------------------------------------------------------------------
# Credit Model Tests
# ------------------------------------------------------------------

class TestCreditModel:
    def setup_method(self):
        from models.credit_model import CreditModel
        self.model = CreditModel()

    def test_pd_is_probability(self):
        pd_val = self.model.predict_pd(5.0, 2.5)
        assert 0 < pd_val < 1

    def test_higher_unemployment_raises_pd(self):
        pd_low = self.model.predict_pd(3.0, 2.5)
        pd_high = self.model.predict_pd(10.0, 2.5)
        assert pd_high > pd_low

    def test_batch_prediction_shape(self):
        df = pd.DataFrame({"unemployment": [4, 8, 12], "inflation": [2, 4, 6]})
        pds = self.model.predict_pd_batch(df)
        assert len(pds) == 3
        assert all(0 < p < 1 for p in pds)

    def test_pd_to_rating_returns_string(self):
        rating = self.model.pd_to_rating(0.01)
        assert isinstance(rating, str)
        assert rating in ["AAA", "AA", "A", "BBB", "BB", "B", "CCC", "D"]

    def test_stress_test_returns_dataframe(self):
        df = self.model.stress_test()
        assert isinstance(df, pd.DataFrame)
        assert "predicted_pd" in df.columns
        assert "rating" in df.columns
        assert len(df) > 0

    def test_sensitivity_keys(self):
        sens = self.model.sensitivity()
        assert "base_pd" in sens
        assert "unemployment_shock_delta" in sens
        assert "inflation_shock_delta" in sens

    def test_unemployment_shock_positive(self):
        sens = self.model.sensitivity()
        assert sens["unemployment_shock_delta"] > 0  # higher unemployment → higher PD


# ------------------------------------------------------------------
# VAR Model Tests
# ------------------------------------------------------------------

class TestVARModel:
    def setup_method(self):
        from models.var_model import VARModel
        self.VARModel = VARModel

    def test_fit_and_forecast(self, sample_macro_df):
        model = self.VARModel(lags=1)
        model.fit(sample_macro_df)
        fc = model.forecast(steps=1)
        assert fc.shape == (1, 2)

    def test_forecast_before_fit_raises(self):
        model = self.VARModel(lags=1)
        with pytest.raises(ValueError):
            model.forecast()

    def test_stationarity_returns_dict(self, sample_macro_df):
        model = self.VARModel(lags=1)
        result = model.check_stationarity(sample_macro_df)
        assert "unemployment" in result
        assert "inflation" in result
        assert "p_value" in result["unemployment"]

    def test_forecast_with_intervals_shape(self, sample_macro_df):
        model = self.VARModel(lags=1)
        model.fit(sample_macro_df)
        fc, lo, hi = model.forecast_with_intervals(steps=2)
        assert fc.shape == (2, 2)
        assert lo.shape == (2, 2)
        assert hi.shape == (2, 2)
        # Lower bound should be <= forecast <= upper bound
        assert np.all(lo <= fc + 1e-10)
        assert np.all(fc <= hi + 1e-10)


# ------------------------------------------------------------------
# Pipeline Tests
# ------------------------------------------------------------------

class TestPipeline:
    def test_pipeline_returns_required_keys(self):
        from pipeline.run_pipeline import run_pipeline
        result = run_pipeline(run_stress=False, verbose=False)
        required_keys = {"forecast", "forecast_ci", "predicted_pd", "rating",
                         "sensitivity", "stationarity", "var_lags_used"}
        assert required_keys.issubset(result.keys())

    def test_pipeline_pd_is_probability(self):
        from pipeline.run_pipeline import run_pipeline
        result = run_pipeline(run_stress=False, verbose=False)
        assert 0 < result["predicted_pd"] < 1

    def test_pipeline_rating_is_valid(self):
        from pipeline.run_pipeline import run_pipeline
        valid = {"AAA", "AA", "A", "BBB", "BB", "B", "CCC", "D"}
        result = run_pipeline(run_stress=False, verbose=False)
        assert result["rating"] in valid

    def test_pipeline_stress_test_included(self):
        from pipeline.run_pipeline import run_pipeline
        result = run_pipeline(run_stress=True, verbose=False)
        assert result["stress_test"] is not None
        assert len(result["stress_test"]) > 0


# ------------------------------------------------------------------
# API Tests
# ------------------------------------------------------------------

class TestAPI:
    @pytest.fixture(autouse=True)
    def setup_client(self):
        from api.server import app
        self.client = TestClient(app)

    def test_health_check(self):
        r = self.client.get("/health")
        assert r.status_code == 200
        assert r.json()["status"] == "ok"

    def test_forecast_and_score(self):
        r = self.client.get("/forecast_and_score")
        assert r.status_code == 200
        data = r.json()
        assert "predicted_pd" in data
        assert "rating" in data
        assert 0 < data["predicted_pd"] < 1

    def test_score_endpoint(self):
        r = self.client.post("/score", json={"unemployment": 8.0, "inflation": 4.0})
        assert r.status_code == 200
        data = r.json()
        assert "predicted_pd" in data
        assert "rating" in data

    def test_score_invalid_input(self):
        # unemployment = -1 is invalid (ge=0 constraint)
        r = self.client.post("/score", json={"unemployment": -1, "inflation": 2.0})
        assert r.status_code == 422

    def test_stress_test_endpoint(self):
        r = self.client.get("/stress_test")
        assert r.status_code == 200
        scenarios = r.json()["scenarios"]
        assert len(scenarios) > 0
        assert "predicted_pd" in scenarios[0]

    def test_custom_stress_test(self):
        payload = [
            {"unemployment": 5.0, "inflation": 2.0},
            {"unemployment": 12.0, "inflation": 6.0},
        ]
        r = self.client.post("/stress_test/custom", json=payload)
        assert r.status_code == 200
        assert len(r.json()["scenarios"]) == 2
